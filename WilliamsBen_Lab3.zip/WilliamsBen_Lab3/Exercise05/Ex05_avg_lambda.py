grades = [90, 74, 87, 80]

avg = (lambda xs: sum(xs) / len(xs))(grades)
print("Grades:", grades)
print("Average:", avg)
