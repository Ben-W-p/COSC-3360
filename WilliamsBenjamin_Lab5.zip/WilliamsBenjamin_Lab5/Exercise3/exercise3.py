class Dog:
    def __init__(self, breed, color):
        self.breed = breed
        self.color = color
Dog1 = Dog("German Shepard", "Brown")
print('------Dog1------')
print("Breed:", Dog1.breed)
print("Color:", Dog1.color)
